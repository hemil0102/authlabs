
import Foundation

protocol RequestProvidable {
    var request: URLRequest? { get }
}
