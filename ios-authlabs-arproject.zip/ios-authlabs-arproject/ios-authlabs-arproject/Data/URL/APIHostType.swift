
enum APIHostType: String {
    case chatGPT = "api.openai.com"
    case google = "www.googleapis.com"
}
