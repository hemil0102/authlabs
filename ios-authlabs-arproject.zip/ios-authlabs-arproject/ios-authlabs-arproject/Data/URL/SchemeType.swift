
enum SchemeType: String {
    case http = "http"
    case https = "https"
}

