
import Foundation

struct GPTAnswer: Hashable {
    let content: String
}
